import '@fontsource/roboto' // Defaults to weight 400
import '@fontsource/roboto/300.css' // Specify weight
import '@fontsource/roboto/400.css' // Specify weight
import '@fontsource/roboto/500.css' // Specify weight
import '@fontsource/roboto/700.css' // Specify weight
import '@fontsource/roboto/900.css' // Specify weight
import '@fontsource/roboto/400-italic.css' // Specify weight and style
import 'material-icons/iconfont/material-icons.css'
import './index.css'
import 'rc-input-number/assets/index.css'
import 'react-toastify/dist/ReactToastify.css'
import 'react-datepicker/dist/react-datepicker.css'
import 'perfect-scrollbar/css/perfect-scrollbar.css'
import './styles/reactDatePicker.css'
import './styles/accordion.css'

import { StyledEngineProvider } from '@mui/material'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ConfirmProvider } from 'material-ui-confirm'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { ToastContainer } from 'react-toastify'

import App from './App'

createRoot(document.getElementById('root') as HTMLElement).render(
  <StrictMode>
    <StyledEngineProvider injectFirst>
      <BrowserRouter>
        <ConfirmProvider
          defaultOptions={{
            title: 'Confirmación',
            content: '¿Confirma que desea realizar la acción?',
            allowClose: false,
            confirmationText: 'Confirmar',
            cancellationText: 'Cancelar',
            dialogProps: {
              fullWidth: true,
              maxWidth: 'xs',
            },
            confirmationButtonProps: {
              color: 'primary',
              variant: 'contained',
              autoFocus: true,
              size: 'small',
              sx: { mr: 1.5 },
            },
            cancellationButtonProps: { color: 'error', variant: 'text', size: 'small' },
            buttonOrder: ['cancel', 'confirm'],
          }}
        >
          <QueryClientProvider client={new QueryClient()}>
            <App />
            <ToastContainer limit={3} />
          </QueryClientProvider>
        </ConfirmProvider>
      </BrowserRouter>
    </StyledEngineProvider>
  </StrictMode>,
)
