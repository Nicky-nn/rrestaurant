import { Button, Grid, Typography } from '@mui/material'

import SimpleContainer from '../../base/components/Container/SimpleContainer'
import Breadcrumb from '../../base/components/Template/Breadcrumb/Breadcrumb'
import { H2 } from '../../base/components/Template/Typography'
import useAuth from '../../base/hooks/useAuth'
import { homeRoutesMap } from './HomeRoutes'

/**
 * @description Dashboard inicial
 * @constructor
 */
const Home = () => {
  const { user } = useAuth()
  return (
    <SimpleContainer maxWidth={'xl'}>
      <Breadcrumb routeSegments={[homeRoutesMap.home]} />
      <H2>
        Página Principal para el usuario con correo {user.miEmpresa.email}{' '}
        {user.miEmpresa.emailFake}
      </H2>
      <hr />
      <Grid container spacing={2}>
        <Grid item xs>
          <Typography variant="body1" color={'primary'} gutterBottom>
            ¡Bienvenido a la plantilla ISI-TEMPLATE a continuacion se muestra el color
            primario
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="body1" color={'secondary'} gutterBottom>
            ¡Bienvenido a la plantilla ISI-TEMPLATE, a continuacion se muestra el color
            secundario
          </Typography>
        </Grid>
        <Grid item xs={12}>
          {' '}
          <Button variant="contained" color="primary">
            Botón Primario
          </Button>
        </Grid>
        <Grid item xs={12}>
          {' '}
          <Button variant="contained" color="secondary">
            Botón secundario
          </Button>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained" color="success">
            Botón success
          </Button>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained" color="error">
            Botón error
          </Button>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained" color="info">
            Botón info
          </Button>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained" color="warning">
            Botón warning
          </Button>
        </Grid>
      </Grid>
    </SimpleContainer>
  )
}

export default Home
